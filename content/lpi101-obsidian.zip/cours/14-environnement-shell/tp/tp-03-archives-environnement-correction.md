# TP 03. Sauvegarder un dossier et préparer son shell — Correction

> Essaie chaque question avant d’ouvrir **Afficher la correction**. Chaque réponse se replie indépendamment.

> Durée estimée : 50 min

> Chapitres associés : [13. Archiver et compresser](../../13-archives-compression/13-archives-compression.md), [14. Variables, environnement et historique](../14-environnement-shell.md)

---

## Objectifs

- Créer une archive, vérifier son contenu et la restaurer.
- Utiliser des variables et distinguer expansion et texte littéral.
- Comprendre PATH et retrouver une commande.

## Avant de commencer

Utilise un compte standard dans la VM Debian. Les parties se suivent dans le même terminal.

**Préparation fournie :**

```bash
mkdir -p ~/lpi101-tp/tp03/source
cd ~/lpi101-tp/tp03
printf 'Compte rendu\n' > source/rapport.txt
printf 'Paramètre de test\n' > source/.reglage
```

---

## Partie A — Archiver et restaurer (25 min)

**A1.** Crée une archive compressée `projet.tar.gz` de `source`, puis liste son contenu sans l’extraire. Le fichier caché est-il présent ?

> [!success]- Afficher la correction — A1
> ```bash
> tar -czf projet.tar.gz source
> tar -tzf projet.tar.gz
> ```
>
> Oui : on archive le dossier lui-même, pas seulement la sélection `source/*` qui omet habituellement les fichiers cachés.

**A2.** Restaure l’archive dans `restauration`, puis compare le fichier restauré avec celui de départ.

> [!success]- Afficher la correction — A2
> ```bash
> mkdir restauration
> tar -xzf projet.tar.gz -C restauration
> cmp source/rapport.txt restauration/source/rapport.txt
> ```
>
> `cmp` ne produit rien et renvoie 0 si les contenus sont identiques. Le chemin `source/` était enregistré dans l’archive.

**A3.** Compresse une copie de `rapport.txt` avec gzip, puis décompresse-la. Que devient le fichier d’entrée par défaut ?

> [!success]- Afficher la correction — A3
> ```bash
> cp source/rapport.txt rapport.txt
> gzip rapport.txt
> ls rapport.txt.gz
> gunzip rapport.txt.gz
> cat rapport.txt
> ```
>
> Par défaut, gzip remplace le fichier d’entrée par sa version compressée ; `-k` permet de le conserver. Archiver et compresser sont deux opérations distinctes.

---

## Partie B — Variables et environnement (15 min)

**B1.** Crée la variable `message` contenant `Bonjour Linux`. Affiche-la avec des guillemets doubles puis simples et explique la différence.

> [!success]- Afficher la correction — B1
> ```bash
> message="Bonjour Linux"
> echo "$message"
> echo '$message'
> ```
>
> Les doubles permettent l’expansion ; les simples affichent littéralement `$message`. L’affectation n’a pas d’espaces autour de `=`.

**B2.** Exporte la variable, lis-la depuis un nouveau Bash, puis supprime-la de la session.

> [!success]- Afficher la correction — B2
> ```bash
> export message
> bash -c 'echo "$message"'
> unset message
> ```
>
> Le processus enfant reçoit les variables exportées. L’export n’est pas une écriture dans un fichier de configuration.

**B3.** Affiche HOME et PATH. Comment lancerais-tu un script `outil.sh` présent dans ton dossier actuel et absent de PATH ?

> [!success]- Afficher la correction — B3
> ```bash
> echo "$HOME"
> printf '%s\n' "$PATH"
> command -v bash
> ```
>
> On peut utiliser `./outil.sh` s’il est exécutable, ou `bash outil.sh` s’il est lisible. Ne pas retirer les répertoires existants de PATH.

---

## Partie C — Réutiliser une commande (10 min)

**C1.** Dans ton terminal interactif, retrouve une commande précédente avec les flèches puis avec Ctrl+R. Affiche les dix dernières commandes.

> [!success]- Afficher la correction — C1
> ```bash
> history 10
> ```
>
> Les commandes du script de test ne constituent pas l’historique interactif de l’élève. Cette partie s’effectue dans le terminal ouvert.

**C2.** Pourquoi une archive conservée uniquement sur le même disque n’est-elle pas une sauvegarde suffisante ?

> [!success]- Afficher la correction — C2
> Une panne ou la perte de ce disque peut supprimer les données et leur archive. Une sauvegarde doit être conservée séparément et sa restauration vérifiée.
